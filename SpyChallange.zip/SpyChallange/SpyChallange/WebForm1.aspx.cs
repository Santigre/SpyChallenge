﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SpyChallange
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack)
            {
                string[] assets = new string[0];
                int[] rigged = new int[0];
                int[] acts = new int[0];

                ViewState.Add("Assets", assets);
                ViewState.Add("Rigged", rigged);
                ViewState.Add("Acts", acts);
            }
        }

        protected void addButton_Click(object sender, EventArgs e)
        {
            string[] assets = (string[])ViewState["Assets"];
            int[] rigged = (int[])ViewState["Rigged"];
            int[] acts = (int[])ViewState["Acts"];

            int newLength = assets.Length + 1;

            Array.Resize(ref assets, newLength);
            Array.Resize(ref rigged, newLength);
            Array.Resize(ref acts, newLength);

            int newIndex = assets.GetUpperBound(0);

            assets[newIndex] = assetTextBox.Text;
            rigged[newIndex] = int.Parse(riggedTextBox.Text);
            acts[newIndex] = int.Parse(actsTextBox.Text);

            ViewState["Assets"] = assets;
            ViewState["Rigged"] = rigged;
            ViewState["Acts"] = acts;

                resultLabel.Text = String.Format("Total Elections Rigged: {0} <br />Avrage Acts of Subterfuge per Asset: {1:N2}<br />(Last Asset you have added {2})",
                rigged.Sum(),
                acts.Average(),
                assets[newIndex]);

            assetTextBox.Text = "";
            riggedTextBox.Text = "";
            actsTextBox.Text = "";



        }
    }
}